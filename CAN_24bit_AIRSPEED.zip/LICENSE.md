Until further notified, All drawings in here are CC-BY-NC 3.0
